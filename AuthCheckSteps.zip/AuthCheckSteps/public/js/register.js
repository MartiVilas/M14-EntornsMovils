const $ = (el) => document.querySelector(el);
const registerForm = $("#register-form");
const registerSpan = $("#register-form span");

registerForm?.addEventListener("submit", (e) => {
  e.preventDefault();
  const username = $("#register-username").value;
  const password = $("#register-password").value;
  const confirmPassword = $("#register-confirm-password").value;

  if (password !== confirmPassword) {
    alert("Les contrasenyes no coincideixen");
    return;
  }

  fetch("/register", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ username, password }),
  }).then((res) => {
    console.log(res);
    if (res.ok) {
      registerSpan.innerText = "Usuari registrat correctament. Entrant...";
      registerSpan.classList.add("success");
      setTimeout(() => {
        window.location.href = "/protected";
      }, 2000);
    } else {
      registerSpan.innerText = "Error en registrar l’usuari";
      registerSpan.classList.add("error");
    }
  });
});
