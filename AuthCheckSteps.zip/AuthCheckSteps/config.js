export const {
    PORT=3000,
    SALT_ROUNDS=10 ,
    SECRET_JWT_KEY="aixo-es-una-super-paraula-secreta" 
}=process.env