export const {
    PORT = 3000,
    SALT_ROUNDS=5,
    SECRET_JWT_KEY="123456789"
} = process.env;